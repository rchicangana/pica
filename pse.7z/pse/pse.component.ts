import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pse',
  templateUrl: './pse/StartTransaction.htm',
  styleUrls: ['./pse.component.scss']
})
export class PseComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
